from datetime import date
today = date.today()

d2 = today.strftime("%B %d, %Y")
import mysql.connector
from mysql.connector import errorcode
config ={
    "user" : "root",
    "password": "mysql333",
    "host" : "127.0.0.1",
    "database" : "final_project",
    "raise_on_warnings" : True
}
db=mysql.connector.connect(**config)
cursor=db.cursor()

query = "SELECT count(*) as May_Client_Total FROM clients WHERE _dateJoined between '2022-05-01' AND '2022-05-31';"
querya = "SELECT count(*) as June_Client_Total FROM clients WHERE _dateJoined between '2022-06-01' AND '2022-06-30';"
queryb = "SELECT count(*) as July_Client_Total FROM clients WHERE _dateJoined between '2022-07-01' AND '2022-07-31';"
cursor.execute(query)
clients = cursor.fetchall()
cursor.execute(querya)
clientsa = cursor.fetchall()
cursor.execute(queryb)
clientsb = cursor.fetchall()

print("\n")
print("Report Date:",d2)
print("---------------------------------------------------------------------\n  DISPLAYING MONTHLY RECORDS FOR LAST SIX MONTHS \n---------------------------------------------------------------------")
for client in clients:
    print(" May Client Total: {}".format(client[0]))
for clien in clientsa:
    print(" June Client Total: {}".format(clien[0]))
for clie in clientsb:
    print(" July Client Total: {}".format(clie[0]))

query = "SELECT c._company, a._value FROM clients c LEFT JOIN assets a ON a._asset_id = c._client_id GROUP BY c._company;"
query2 = "SELECT ROUND(AVG(_value),2) AS Average FROM assets;"
cursor.execute(query)
company=cursor.fetchall()
cursor.execute(query2)
average=cursor.fetchall()
print("\n")
print("Report Date:",d2)
print("---------------------------------------------------------------------\n  AVERAGE AMOUNT OF ASSETS (IN CURRENCY) FOR THE ENTIRE CLIENT LIST \n---------------------------------------------------------------------")
for companies in company:
    print(" Company: {}\n Value: ${} \n".format(companies[0], companies[1]))
print("==========================")
for averages in average:
    print("Average Total: ${}\n".format(averages[0]));

query = "SELECT c._name, SUM(t._code) AS codes, MONTHNAME(t._date) FROM clients c LEFT JOIN transactions t ON t._transaction_id = c._client_id WHERE c._client_id = 1 GROUP BY c._name HAVING  codes >= 10;"
cursor.execute(query)
transaction=cursor.fetchall()
print("\n")
print("Report Date:",d2)
print("---------------------------------------------------------------------\n  CLIENTS HAVING A HIGH NUMBER (MORE THAN 10 A MONTH) OF TRANSACTIONS \n---------------------------------------------------------------------")
for transactions in transaction:
    print(" Name: {}\n Number of Transactions: {} \n Date: {}\n".format(transactions[0], transactions[1], transactions[2],))